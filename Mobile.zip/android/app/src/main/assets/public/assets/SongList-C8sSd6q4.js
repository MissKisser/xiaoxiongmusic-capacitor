import{bB as Le,bC as G,bD as Z,bE as E,bF as W,d as ee,a1 as M,bG as he,bH as se,bI as Se,I as j,bJ as Q,bK as We,bL as Ge,bM as _e,bN as Ke,bO as Qe,bP as Xe,bQ as Ye,bR as Je,o as Ze,bS as et,bT as Be,bU as tt,N as A,bV as ot,bW as Re,bX as nt,bY as st,T as le,bZ as at,b_ as it,b$ as rt,c0 as lt,c1 as dt,bq as De,L as Ie,b as ke,c as we,M as Oe,e as xe,c2 as ut,j as i,t as H,q as F,G as K,m as t,h as c,v as ce,w as r,x as h,y as D,z as Ne,k as C,bA as Ce,B as z,D as pe,aW as ct,c3 as pt,aj as mt,F as de,A as be,bo as Pe,C as ft,aY as yt,aX as gt,c4 as bt,ax as vt,$ as Ae,be as ht,c5 as St,c6 as ye,K as $e,c7 as _t,O as kt,aH as B,c8 as wt,aJ as ge,c9 as xt,ca as Ct,cb as $t,cc as zt,cd as Mt,ad as Rt,ce as Pt,cf as Tt,cg as Lt,aG as Bt,ch as Fe,bz as ve,ci as Dt,a5 as It,cj as Ot,ck as Nt,cl as At,cm as Ft,P as Ht,aS as qt,ay as jt,bn as Vt,cn as Ut,co as Et,cp as Te,al as Wt,cq as Gt,cr as Kt,cs as Qt,ap as Xt,ae as Yt}from"./index-DVrhDZmS.js";function Jt(o){const{popoverColor:l,dividerColor:a,borderRadius:m}=o;return{color:l,buttonBorderColor:a,borderRadiusSquare:m,boxShadow:"0 2px 8px 0px rgba(0, 0, 0, .12)"}}const Zt={common:Le,self:Jt},eo=G("float-button-group",[G("float-button",`
 position: relative;
 `),Z("square-shape",`
 background-color: var(--n-color);
 cursor: pointer;
 display: flex;
 width: fit-content;
 align-items: center;
 justify-content: center;
 border-radius: var(--n-border-radius-square);
 flex-direction: column;
 box-shadow: var(--n-box-shadow);
 transition:
 color .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `,[G("float-button",`
 background-color: unset;
 border-radius: 0;
 box-shadow: none;
 box-sizing: content-box;
 `,[E("&:not(:last-child)",`
 border-bottom: 1px solid var(--n-button-border-color); 
 `),E("&:first-child",`
 border-top-left-radius: 4px;
 border-top-right-radius: 4px;
 `),E("&:last-child",`
 border-bottom-left-radius: 4px;
 border-bottom-right-radius: 4px;
 `),W("fill",`
 top: 4px;
 right: 4px;
 bottom: 4px;
 left: 4px;
 border-radius: var(--n-border-radius-square); 
 `)])]),Z("circle-shape",[E(">:not(:last-child)",`
 margin-bottom: 16px;
 `)])]),to=Object.assign(Object.assign({},se.props),{left:[Number,String],right:[Number,String],top:[Number,String],bottom:[Number,String],shape:{type:String,default:"circle"},position:{type:String,default:"fixed"}}),He=We("n-float-button-group"),oo=ee({name:"FloatButtonGroup",props:to,setup(o){const{mergedClsPrefixRef:l,inlineThemeDisabled:a}=he(o),m=se("FloatButtonGroup","-float-button-group",eo,Zt,o,l),g=j(()=>{const{self:{color:b,boxShadow:f,buttonBorderColor:y,borderRadiusSquare:k},common:{cubicBezierEaseInOut:w}}=m.value;return{"--n-bezier":w,"--n-box-shadow":f,"--n-color":b,"--n-button-border-color":y,"--n-border-radius-square":k,position:o.position,left:Q(o.left)||"",right:Q(o.right)||"",top:Q(o.top)||"",bottom:Q(o.bottom)||""}});Ge(He,{shapeRef:_e(o,"shape")});const s=a?Se("float-button",void 0,g,o):void 0;return{cssVars:a?void 0:g,mergedClsPrefix:l,themeClass:s?.themeClass,onRender:s?.onRender}},render(){const{mergedClsPrefix:o,cssVars:l,shape:a}=this;return M("div",{class:[`${o}-float-button-group`,`${o}-float-button-group--${a}-shape`],style:l,role:"group"},this.$slots)}});function no(o){const{popoverColor:l,textColor2:a,buttonColor2Hover:m,buttonColor2Pressed:g,primaryColor:s,primaryColorHover:b,primaryColorPressed:f,borderRadius:y}=o;return{color:l,colorHover:m,colorPressed:g,colorPrimary:s,colorPrimaryHover:b,colorPrimaryPressed:f,textColor:a,boxShadow:"0 2px 8px 0px rgba(0, 0, 0, .16)",boxShadowHover:"0 2px 12px 0px rgba(0, 0, 0, .24)",boxShadowPressed:"0 2px 12px 0px rgba(0, 0, 0, .24)",textColorPrimary:"#fff",borderRadiusSquare:y}}const so={common:Le,self:no},ao=G("float-button",`
 user-select: none;
 cursor: pointer;
 color: var(--n-text-color);
 background-color: var(--n-color);
 font-size: 18px;
 transition:
 color .3s var(--n-bezier),
 border-color .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 box-shadow: var(--n-box-shadow);
 display: flex;
 align-items: stretch;
 box-sizing: border-box;
`,[Z("circle-shape",`
 border-radius: 4096px;
 `),Z("square-shape",`
 border-radius: var(--n-border-radius-square);
 `),W("fill",`
 position: absolute;
 top: 0;
 right: 0;
 bottom: 0
 left: 0;
 transition: background-color .3s var(--n-bezier);
 border-radius: inherit;
 `),W("body",`
 position: relative;
 flex-grow: 1;
 display: flex;
 align-items: center;
 justify-content: center;
 transition: transform .3s var(--n-bezier), opacity .3s var(--n-bezier);
 border-radius: inherit;
 flex-direction: column;
 box-sizing: border-box;
 padding: 2px 4px;
 gap: 2px;
 transform: scale(1);
 `,[W("description",`
 font-size: 12px;
 text-align: center;
 line-height: 14px;
 `)]),E("&:hover","box-shadow: var(--n-box-shadow-hover);",[E(">",[W("fill",`
 background-color: var(--n-color-hover);
 `)])]),E("&:active","box-shadow: var(--n-box-shadow-pressed);",[E(">",[W("fill",`
 background-color: var(--n-color-pressed);
 `)])]),Z("show-menu",[E(">",[W("menu",`
 pointer-events: all;
 bottom: 100%;
 opacity: 1;
 `),W("close",`
 transform: scale(1);
 opacity: 1;
 `),W("body",`
 transform: scale(0.75);
 opacity: 0;
 `)])]),W("close",`
 opacity: 0;
 transform: scale(0.75);
 position: absolute;
 top: 0;
 right: 0;
 bottom: 0;
 left: 0;
 display: flex;
 align-items: center;
 justify-content: center;
 transition: transform .3s var(--n-bezier), opacity .3s var(--n-bezier);
 `),W("menu",`
 position: absolute;
 bottom: calc(100% - 8px);
 display: flex;
 flex-direction: column;
 opacity: 0;
 pointer-events: none;
 transition:
 opacity .3s var(--n-bezier),
 bottom .3s var(--n-bezier); 
 `,[E("> *",`
 margin-bottom: 16px;
 `),G("float-button",`
 position: relative !important;
 `)])]),io=Object.assign(Object.assign({},se.props),{width:{type:[Number,String],default:40},height:{type:[Number,String],default:40},left:[Number,String],right:[Number,String],top:[Number,String],bottom:[Number,String],shape:{type:String,default:"circle"},position:{type:String,default:"fixed"},type:{type:String,default:"default"},menuTrigger:String,showMenu:{type:Boolean,default:void 0},onUpdateShowMenu:{type:[Function,Array],default:void 0},"onUpdate:showMenu":{type:[Function,Array],default:void 0}}),ro=ee({name:"FloatButton",props:io,slots:Object,setup(o){const{mergedClsPrefixRef:l,inlineThemeDisabled:a}=he(o),m=A(null),g=se("FloatButton","-float-button",ao,so,o,l),s=ot(He,null),b=A(!1),f=_e(o,"showMenu"),y=Je(f,b);function k(d){const{onUpdateShowMenu:p,"onUpdate:showMenu":I}=o;b.value=d,p&&Re(p,d),I&&Re(I,d)}const w=j(()=>{const{self:{color:d,textColor:p,boxShadow:I,boxShadowHover:O,boxShadowPressed:_,colorHover:V,colorPrimary:P,colorPrimaryHover:te,textColorPrimary:oe,borderRadiusSquare:X,colorPressed:ue,colorPrimaryPressed:me},common:{cubicBezierEaseInOut:fe}}=g.value,{type:J}=o;return{"--n-bezier":fe,"--n-box-shadow":I,"--n-box-shadow-hover":O,"--n-box-shadow-pressed":_,"--n-color":J==="primary"?P:d,"--n-text-color":J==="primary"?oe:p,"--n-color-hover":J==="primary"?te:V,"--n-color-pressed":J==="primary"?me:ue,"--n-border-radius-square":X}}),$=j(()=>{const{width:d,height:p}=o;return Object.assign({position:s?void 0:o.position,width:Q(d),minHeight:Q(p)},s?null:{left:Q(o.left),right:Q(o.right),top:Q(o.top),bottom:Q(o.bottom)})}),e=j(()=>s?s.shapeRef.value:o.shape),v=()=>{o.menuTrigger==="hover"&&k(!0)},S=()=>{o.menuTrigger==="hover"&&y.value&&k(!1)},R=()=>{o.menuTrigger==="click"&&k(!y.value)},n=a?Se("float-button",j(()=>o.type[0]),w,o):void 0;return Ze(()=>{const d=m.value;d&&et("mousemoveoutside",d,S)}),Be(()=>{const d=m.value;d&&tt("mousemoveoutside",d,S)}),{inlineStyle:$,selfElRef:m,cssVars:a?void 0:w,mergedClsPrefix:l,mergedShape:e,mergedShowMenu:y,themeClass:n?.themeClass,onRender:n?.onRender,Mouseenter:v,handleMouseleave:S,handleClick:R}},render(){var o;const{mergedClsPrefix:l,cssVars:a,mergedShape:m,type:g,menuTrigger:s,mergedShowMenu:b,themeClass:f,$slots:y,inlineStyle:k,onRender:w}=this;return w?.(),M("div",{ref:"selfElRef",class:[`${l}-float-button`,`${l}-float-button--${m}-shape`,`${l}-float-button--${g}-type`,b&&`${l}-float-button--show-menu`,f],style:[a,k],onMouseenter:this.Mouseenter,onMouseleave:this.handleMouseleave,onClick:this.handleClick,role:"button"},M("div",{class:`${l}-float-button__fill`,"aria-hidden":!0}),M("div",{class:`${l}-float-button__body`},(o=y.default)===null||o===void 0?void 0:o.call(y),Ye(y.description,$=>$?M("div",{class:`${l}-float-button__description`},$):null)),s?M("div",{class:`${l}-float-button__close`},M(Qe,{clsPrefix:l},{default:()=>M(Xe,null)})):null,s?M("div",{onClick:$=>{$.stopPropagation()},"data-float-button-menu":!0,class:`${l}-float-button__menu`},Ke(y.menu,()=>[])):null)}}),lo=E([E("@keyframes spin-rotate",`
 from {
 transform: rotate(0);
 }
 to {
 transform: rotate(360deg);
 }
 `),G("spin-container",`
 position: relative;
 `,[G("spin-body",`
 position: absolute;
 top: 50%;
 left: 50%;
 transform: translateX(-50%) translateY(-50%);
 `,[nt()])]),G("spin-body",`
 display: inline-flex;
 align-items: center;
 justify-content: center;
 flex-direction: column;
 `),G("spin",`
 display: inline-flex;
 height: var(--n-size);
 width: var(--n-size);
 font-size: var(--n-size);
 color: var(--n-color);
 `,[Z("rotate",`
 animation: spin-rotate 2s linear infinite;
 `)]),G("spin-description",`
 display: inline-block;
 font-size: var(--n-font-size);
 color: var(--n-text-color);
 transition: color .3s var(--n-bezier);
 margin-top: 8px;
 `),G("spin-content",`
 opacity: 1;
 transition: opacity .3s var(--n-bezier);
 pointer-events: all;
 `,[Z("spinning",`
 user-select: none;
 -webkit-user-select: none;
 pointer-events: none;
 opacity: var(--n-opacity-spinning);
 `)])]),uo={small:20,medium:18,large:16},co=Object.assign(Object.assign({},se.props),{contentClass:String,contentStyle:[Object,String],description:String,stroke:String,size:{type:[String,Number],default:"medium"},show:{type:Boolean,default:!0},strokeWidth:Number,rotate:{type:Boolean,default:!0},spinning:{type:Boolean,validator:()=>!0,default:void 0},delay:Number}),po=ee({name:"Spin",props:co,slots:Object,setup(o){const{mergedClsPrefixRef:l,inlineThemeDisabled:a}=he(o),m=se("Spin","-spin",lo,it,o,l),g=j(()=>{const{size:y}=o,{common:{cubicBezierEaseInOut:k},self:w}=m.value,{opacitySpinning:$,color:e,textColor:v}=w,S=typeof y=="number"?rt(y):w[lt("size",y)];return{"--n-bezier":k,"--n-opacity-spinning":$,"--n-size":S,"--n-color":e,"--n-text-color":v}}),s=a?Se("spin",j(()=>{const{size:y}=o;return typeof y=="number"?String(y):y[0]}),g,o):void 0,b=dt(o,["spinning","show"]),f=A(!1);return at(y=>{let k;if(b.value){const{delay:w}=o;if(w){k=window.setTimeout(()=>{f.value=!0},w),y(()=>{clearTimeout(k)});return}}f.value=b.value}),{mergedClsPrefix:l,active:f,mergedStrokeWidth:j(()=>{const{strokeWidth:y}=o;if(y!==void 0)return y;const{size:k}=o;return uo[typeof k=="number"?"medium":k]}),cssVars:a?void 0:g,themeClass:s?.themeClass,onRender:s?.onRender}},render(){var o,l;const{$slots:a,mergedClsPrefix:m,description:g}=this,s=a.icon&&this.rotate,b=(g||a.description)&&M("div",{class:`${m}-spin-description`},g||((o=a.description)===null||o===void 0?void 0:o.call(a))),f=a.icon?M("div",{class:[`${m}-spin-body`,this.themeClass]},M("div",{class:[`${m}-spin`,s&&`${m}-spin--rotate`],style:a.default?"":this.cssVars},a.icon()),b):M("div",{class:[`${m}-spin-body`,this.themeClass]},M(st,{clsPrefix:m,style:a.default?"":this.cssVars,stroke:this.stroke,"stroke-width":this.mergedStrokeWidth,class:`${m}-spin`}),b);return(l=this.onRender)===null||l===void 0||l.call(this),a.default?M("div",{class:[`${m}-spin-container`,this.themeClass],style:this.cssVars},M("div",{class:[`${m}-spin-content`,this.active&&`${m}-spin-content--spinning`,this.contentClass],style:this.contentStyle},a),M(le,{name:"fade-in-transition"},{default:()=>this.active?f:null})):f}}),mo={class:"song-card"},fo={class:"title"},yo={class:"name"},go={key:4,class:"artists"},bo={key:5,class:"artists"},vo={key:0,class:"album text-hidden"},ho=ee({__name:"SongCard",props:{song:{},index:{},hiddenCover:{type:Boolean},hiddenAlbum:{type:Boolean},hiddenSize:{type:Boolean}},emits:["show-menu"],setup(o,{emit:l}){const a=o,m=l,{isSmallScreen:g}=De(),s=Ae(),b=Ie(),f=ke(),y=we(),k=Oe(),w=xe(),$=ut(),e=_e(a,"song"),v=j(()=>e.value.quality===ye.HiRes||e.value.quality===ye.SQ?"warning":e.value.quality===ye.HQ?"info":"primary"),S=async R=>{if(!ht||!R)return;const n=e.value.path;if(!n||e.value.type==="streaming")return;const d=e.value.cover;if(d&&d!=="/images/song.jpg?asset"&&!d.startsWith("blob:")||$.hasBlobURL(n))return;const p=n,I=await window.electron.ipcRenderer.invoke("get-music-cover",p);if(e.value.path!==p||!I)return;const{data:O,format:_}=I,V=$.createBlobURL(O,_,p);V&&e.value.path===p&&(e.value.cover=V)};return(R,n)=>{const d=ce,p=Ne,I=Ce,O=ct,_=mt,V=pe;return i(),H("div",mo,[F("div",{class:vt(["song-content",{play:t(f).playSong.id===t(e).id}])},[F("div",{class:"num",onDblclick:n[2]||(n[2]=K(()=>{},["stop"]))},[t(f).playSong.id!==t(e).id?(i(),c(d,{key:0,depth:"3"},{default:r(()=>[h(D(o.index+1),1)]),_:1})):(i(),c(p,{key:1,size:22,name:"Music"})),C(p,{size:28,name:t(y).playStatus?"Pause":"Play",class:"status",onClick:n[0]||(n[0]=P=>t(w).playOrPause())},null,8,["name"]),C(p,{size:28,name:"Play",class:"play",onClick:n[1]||(n[1]=P=>t(w).addNextSong(t(e),!0))})],32),F("div",fo,[o.hiddenCover?z("",!0):(i(),c(I,{key:t(e).cover,src:t(e).path?t(e).cover:t(e).coverSize?.s||t(e).cover,class:"cover","onUpdate:show":S},null,8,["src"])),C(V,{size:"small",class:"info",vertical:""},{default:r(()=>[F("div",yo,[C(O,{"line-clamp":1,tooltip:{placement:"top",width:"trigger"},class:"name-text"},{default:r(()=>[h(D(t(k).hideLyricBrackets?t(pt)(t(e)?.name):t(e)?.name||"未知曲目")+" ",1),t(e).alia?.length&&!t(k).hideLyricBrackets?(i(),c(d,{key:0,class:"alia",depth:"3"},{default:r(()=>[h(" ("+D(t(e).alia)+") ",1)]),_:1})):z("",!0)]),_:1})]),C(V,{size:4,wrap:!1,class:"desc",align:"center"},{default:r(()=>[t(e)?.quality&&t(k).showSongQuality?(i(),c(_,{key:0,type:t(v),class:"quality",round:""},{default:r(()=>[h(D(t(e).quality),1)]),_:1},8,["type"])):z("",!0),t(k).showSongOriginalTag?(i(),H(de,{key:1},[t(e).originCoverType===1?(i(),c(_,{key:0,bordered:!1,type:"primary",round:""},{default:r(()=>[...n[11]||(n[11]=[h(" 原 ",-1)])]),_:1})):z("",!0),t(e).originCoverType===2?(i(),c(_,{key:1,bordered:!1,type:"info",round:""},{default:r(()=>[...n[12]||(n[12]=[h(" 翻唱 ",-1)])]),_:1})):z("",!0)],64)):z("",!0),t(k).showSongPrivilegeTag?(i(),H(de,{key:2},[t(e).free===1?(i(),c(_,{key:0,bordered:!1,type:"error",round:""},{default:r(()=>[...n[13]||(n[13]=[h(" VIP ",-1)])]),_:1})):z("",!0),t(e).free===4?(i(),c(_,{key:1,bordered:!1,type:"error",round:""},{default:r(()=>[...n[14]||(n[14]=[h(" EP ",-1)])]),_:1})):z("",!0),t(e)?.pc?(i(),c(_,{key:2,bordered:!1,class:"cloud",type:"info",round:""},{icon:r(()=>[C(p,{name:"Cloud"})]),_:1})):z("",!0)],64)):z("",!0),t(e)?.mv?(i(),c(_,{key:3,bordered:!1,class:"mv",type:"warning",round:"",onClick:n[3]||(n[3]=K(P=>t(s).push({name:"video",query:{id:t(e).mv}}),["stop"]))},{default:r(()=>[...n[15]||(n[15]=[h(" MV ",-1)])]),_:1})):z("",!0),Array.isArray(t(e).artists)?(i(),H("div",go,[(i(!0),H(de,null,be(t(e).artists,P=>(i(),c(d,{key:P.id,class:"ar",onClick:te=>t(Pe)(t(e).artists,P.id)},{default:r(()=>[h(D(P.name),1)]),_:2},1032,["onClick"]))),128))])):t(e).type==="radio"?(i(),H("div",bo,[C(d,{class:"ar"},{default:r(()=>[...n[16]||(n[16]=[h(" 电台节目 ",-1)])]),_:1})])):(i(),H("div",{key:6,class:"artists",onClick:n[4]||(n[4]=P=>t(Pe)(t(e).artists))},[C(d,{class:"ar"},{default:r(()=>[h(D(t(e).artists||"未知艺术家"),1)]),_:1})]))]),_:1})]),_:1})]),t(e).type!=="radio"&&!o.hiddenAlbum&&!t(g)?(i(),H("div",vo,[t(ft)(t(e).album)?(i(),c(d,{key:0,class:"album-text",onClick:n[5]||(n[5]=P=>t(s).push({name:"album",query:{id:t(e).album?.id}}))},{default:r(()=>[h(D(t(e).album?.name||"未知专辑"),1)]),_:1})):(i(),c(d,{key:1,class:"album-text"},{default:r(()=>[h(D(t(e).album||"未知专辑"),1)]),_:1}))])):z("",!0),t(e).type!=="radio"?(i(),H("div",{key:1,class:"actions",onClick:n[9]||(n[9]=K(()=>{},["stop"])),onDblclick:n[10]||(n[10]=K(()=>{},["stop"]))},[t(g)?(i(),c(p,{key:1,name:"More",size:20,onClick:n[8]||(n[8]=K(P=>m("show-menu",P),["stop"]))})):(i(),c(p,{key:0,name:t(b).isLikeSong(t(e).id)?"Favorite":"FavoriteBorder",size:20,onClick:n[6]||(n[6]=K(P=>t(St)(t(e),!t(b).isLikeSong(t(e).id)),["stop"])),onDelclick:n[7]||(n[7]=K(()=>{},["stop"]))},null,8,["name"]))],32)):z("",!0),t(e).type==="radio"&&!t(g)?(i(),c(d,{key:2,class:"meta date",depth:"3"},{default:r(()=>[h(D(t(yt)(t(e).updateTime)),1)]),_:1})):z("",!0),t(e).type==="radio"&&!t(g)?(i(),c(d,{key:3,class:"meta",depth:"3"},{default:r(()=>[h(D(t(gt)(t(e).playCount||0)),1)]),_:1})):z("",!0),t(g)?z("",!0):(i(),c(d,{key:4,class:"meta",depth:"3"},{default:r(()=>[h(D(t(bt)(t(e).duration)),1)]),_:1})),t(e).size&&!o.hiddenSize&&!t(g)?(i(),c(d,{key:5,class:"meta size",depth:"3"},{default:r(()=>[h(D(t(e).size)+"M ",1)]),_:1})):z("",!0)],2)])}}}),So=$e(ho,[["__scopeId","data-v-0b6fc0c2"]]),qe=()=>{const o=Ae(),l=Ie(),a=ke(),m=we(),g=Oe(),s=xe(),b=_t(),f=(e,v)=>{e.path&&window.$dialog.warning({title:"确认删除",content:()=>M("div",{style:{marginTop:"20px"}},[M("div",{style:{marginBottom:"10px",opacity:.8,fontSize:"12px"}},e.path),M("div",null,["确认从本地磁盘中删除 ",M("strong",null,e.name),"？该操作无法撤销！"])]),positiveText:"删除",negativeText:"取消",onPositiveClick:async()=>{if(await window.electron.ipcRenderer.invoke("delete-file",e.path)){v("removeSong",[e.id]);const n=l.playList.findIndex(d=>d.id===e.id);n!==-1&&s.removeSongIndex(n),window.$message.success(`${e.name} 删除成功`)}else window.$message.error(`${e.name} 删除失败，请重试`)}})},y=(e,v)=>{window.$dialog.warning({title:"确认删除",content:`确认从云盘中删除 ${e.name}？该操作无法撤销！`,positiveText:"删除",negativeText:"取消",onPositiveClick:async()=>{if((await Lt(e.id)).code==200){l.cloudPlayList.splice(v,1),l.setCloudPlayList(l.cloudPlayList);const n=l.playList.findIndex(d=>d.id===e.id);n!==-1&&s.removeSongIndex(n),window.$message.success("删除成功")}else window.$message.error("删除失败，请重试")}})},k=async e=>{if(!e?.id)return;const S=(await Pt(e.id))?.data?.[0];if(!S){window.$message.error("获取歌曲信息失败");return}const{id:R,type:n,size:d,br:p,md5:I}=S,O=await Tt(e?.name,n,d,Math.floor(p/1e3),I,R);if(O.code===200){const _=O?.data?.failed?.[0];_?.code!==-200?window.$message.success("导入成功"):window.$message.error(_?.msg||"导入失败，请重试")}else window.$message.error("导入失败，请重试")},w=async(e,v)=>{if(!e?.id)return;const S=window.$message.loading("正在不感兴趣...",{duration:0});try{const R=await Mt(e.id);if(S.destroy(),R.code===200){const n=[...a.dailySongsData.list];if(n.splice(v,1),R.data){const d=Rt([R.data])[0];n.splice(v,0,d)}a.dailySongsData={list:n,timestamp:Date.now()},window.$message.success("已标记为不感兴趣")}else window.$message.error("操作失败，请重试")}catch(R){S.destroy(),window.$message.error("操作失败，请重试"),console.error("不感兴趣操作失败：",R)}};return{getMenuOptions:(e,v,S=0,R=!1,n)=>{const d=l.userLikeData.playlists?.filter(X=>X.userId===l.userData.userId),p=e.type||"song",I=!!e?.mv&&e.mv!==0,O=o.currentRoute.value.name==="cloud",_=!!e?.path,V=kt()===1,P=m.playIndex===v,te=!!S&&d.some(X=>X.id===S),oe=l.downloadingSongs.some(X=>X.song.id===e.id);return[{key:"play",label:"立即播放",props:{onClick:()=>s.addNextSong(e,!0)},icon:B("Play",{size:18})},{key:"play-next",label:"下一首播放",show:!P&&!m.personalFmMode,props:{onClick:()=>s.addNextSong(e,!1)},icon:B("PlayNext",{size:18})},{key:"playlist-add",label:"添加到歌单",show:p!=="streaming",props:{onClick:()=>wt([e],_)},icon:B("AddList",{size:18})},{key:"mv",label:"观看 MV",show:p==="song"&&I,props:{onClick:()=>o.push({name:"video",query:{id:e.mv,type:"mv"}})},icon:B("Video",{size:18})},{key:"line-1",type:"divider"},{key:"dislike",label:"不感兴趣",show:R&&V,props:{onClick:()=>w(e,v)},icon:B("HeartBroken")},{key:"more",label:"更多操作",icon:B("Menu",{size:18}),children:[{key:"code-name",label:`复制${p==="song"?"歌曲":p==="streaming"?"流媒体":"节目"}名称`,props:{onClick:()=>ge(e.name)},icon:B("Copy",{size:18})},{key:"code-id",label:`复制${p==="song"?"歌曲":p==="streaming"?"流媒体":"节目"} ID`,show:!_,props:{onClick:()=>ge(e.id)},icon:B("Copy",{size:18})},{key:"share",label:`分享${p==="song"?"歌曲":"节目"}链接`,show:!_&&p!=="streaming",props:{onClick:()=>ge(`https://music.163.com/#/${p}?id=${e.id}`,"已复制分享链接到剪切板")},icon:B("Share",{size:18})},{key:"line-2",type:"divider",show:_},{key:"meta-edit",label:"音乐标签编辑",show:_,props:{onClick:()=>{e.path&&xt(e)}},icon:B("EditNote",{size:20})}]},{key:"line-two",type:"divider"},{key:"cloud-import",label:"导入至云盘",show:!O&&V&&p==="song"&&!_,props:{onClick:()=>k(e)},icon:B("Cloud")},{key:"delete-playlist",label:"从歌单中删除",show:te&&V&&!O,props:{onClick:()=>Ct(S,[e.id],()=>n("removeSong",[e.id]))},icon:B("Delete")},{key:"delete-cloud",label:"从云盘中删除",show:O,props:{onClick:()=>y(e,v)},icon:B("Delete")},{key:"delete-local",label:"从本地磁盘中删除",show:_&&!P,props:{onClick:()=>f(e,n)},icon:B("Delete")},{key:"open-folder",label:"打开歌曲所在目录",show:_,props:{onClick:()=>window.electron.ipcRenderer.send("open-folder",e.path)},icon:B("SnippetFolder")},{key:"cloud-match",label:"云盘歌曲纠正",show:O,props:{onClick:()=>$t(e?.id,v)},icon:B("AutoFix")},{key:"search",label:"同名搜索",show:g.useOnlineService,props:{onClick:()=>o.push({name:"search",query:{keyword:e.name}})},icon:B("Search")},{key:"download",label:"下载歌曲",show:m.isDeveloperMode&&!_&&p==="song"&&!oe,props:{onClick:()=>zt(e)},icon:B("Download")},{key:"retry-download",label:"重试下载",show:m.isDeveloperMode&&oe,props:{onClick:()=>b.retryDownload(e.id)},icon:B("Refresh")}]}}},_o=ee({__name:"SongListMenu",emits:["removeSong"],setup(o,{expose:l,emit:a}){const m=a,{getMenuOptions:g}=qe(),s=A(0),b=A(0),f=A(!1),y=A([]);return l({openDropdown:(w,$,e,v,S,R=!1)=>{try{w.preventDefault(),f.value=!1;const n=Fe(e),d=g(e,v,S||0,R,(I,O)=>m(I,O)),p={key:"data",type:"render",render:()=>M(pe,{align:"center",wrap:!1,class:"song-list-card"},{default:()=>[M(Ce,{src:e.coverSize?.s}),M(pe,{vertical:!0,size:0},{default:()=>[M(ce,{class:"text-hidden",depth:1},{default:()=>n?.name}),M(ce,{depth:3,class:"text-hidden",style:{fontSize:"12px"}},{default:()=>n?.artist})]})]})};ve().then(()=>{y.value=[p,{key:"header-line",type:"divider"},...d],s.value=w.clientX,b.value=w.clientY,f.value=!0})}catch(n){console.error("右键菜单出现异常：",n),window.$message.error("右键菜单出现异常")}}}),(w,$)=>{const e=Bt;return i(),c(e,{x:t(s),y:t(b),show:t(f),options:t(y),class:"song-list-menu",placement:"bottom-start",trigger:"manual",size:"large",onSelect:$[0]||($[0]=v=>f.value=!1),onClickoutside:$[1]||($[1]=v=>f.value=!1)},null,8,["x","y","show","options"])}}}),ko={class:"menu-header"},wo={class:"info"},xo={class:"name text-hidden"},Co={class:"artist text-hidden"},$o={class:"menu-content"},zo=ee({__name:"MobileSongMenu",emits:["removeSong"],setup(o,{expose:l,emit:a}){const m=a,{getMenuOptions:g}=qe(),s=A(!1),b=A(null),f=A([]),y=($,e,v=0,S=!1)=>{b.value=$,f.value=g($,e,v,S,(R,n)=>m(R,n)),s.value=!0},k=j(()=>b.value?Fe(b.value)?.artist||"未知艺术家":""),w=($,e)=>{const v=e.props?.onClick;typeof v=="function"&&(v(),s.value=!1)};return l({open:y}),($,e)=>{const v=Ot,S=Dt;return i(),c(S,{show:t(s),"onUpdate:show":e[0]||(e[0]=R=>It(s)?s.value=R:null),"auto-focus":!1,placement:"bottom",class:"mobile-song-menu",height:"50vh"},{default:r(()=>[C(v,{"native-scrollbar":!1,"header-style":{padding:"16px 18px"},"body-content-style":{padding:0},closable:""},{header:r(()=>[F("div",ko,[C(Ce,{src:t(b)?.coverSize?.s,class:"cover"},null,8,["src"]),F("div",wo,[F("div",xo,D(t(b)?.name),1),F("div",Co,D(t(k)),1)])])]),default:r(()=>[F("div",$o,[C(t(Nt),{options:t(f),indent:18,"root-indent":18,"onUpdate:value":w},null,8,["options"])])]),_:1})]),_:1},8,["show"])}}}),Mo=$e(zo,[["__scopeId","data-v-c6d6fe61"]]),Ro={class:"list-header song-card sticky-header"},Po={class:"title has-sort"},To={class:"sort-menu"},Lo={class:"group"},Bo={class:"group"},Do={key:1,class:"load-more"},Io={key:1,class:"song-list loading"},Oo=ee({__name:"SongList",props:{data:{},type:{default:"song"},height:{},loading:{type:Boolean},loadMore:{type:Boolean},loadingText:{default:"努力加载中..."},hiddenAlbum:{type:Boolean},hiddenCover:{type:Boolean},hiddenSize:{type:Boolean},hiddenScrollbar:{type:Boolean},disabledSort:{type:Boolean},playListId:{default:0},isDailyRecommend:{type:Boolean,default:!1},doubleClickAction:{},listVersion:{default:0},disableHeightTransition:{type:Boolean}},emits:["reachBottom","scroll","removeSong"],setup(o,{emit:l}){const a=o,m=l,g=ke(),s=we(),b=xe(),{isSmallScreen:f}=De(),y=x=>{f.value&&k(x)},k=x=>{a.doubleClickAction==="add"?b.addNextSong(x,!0):b.updatePlayList(p.value,x,a.playListId)},w=A(0),$=A(0),e=A(null),v=A(null),S=A(!0),R=A(null),n=A(null),d=(x,u,T)=>{f.value?n.value?.open(u,T,a.playListId,a.isDailyRecommend):R.value?.openDropdown(x,p.value,u,T,a.playListId,a.isDailyRecommend)},p=j(()=>{if(a.disabledSort||s.listSortField==="default"||s.listSortOrder==="default")return a.data;const x=[...a.data],u=s.listSortField,ne=s.listSortOrder==="asc";return x.sort((N,q)=>{let U=0;switch(u){case"title":U=N.name.localeCompare(q.name,"zh-CN");break;case"artist":{const ae=Array.isArray(N.artists)?N.artists[0]?.name||"":N.artists||"",ie=Array.isArray(q.artists)?q.artists[0]?.name||"":q.artists||"";U=ae.localeCompare(ie,"zh-CN");break}case"album":{const ae=typeof N.album=="string"?N.album:N.album?.name||"",ie=typeof q.album=="string"?q.album:q.album?.name||"";U=ae.localeCompare(ie,"zh-CN");break}case"duration":U=N.duration-q.duration;break;case"size":U=(N.size||0)-(q.size||0);break;case"createTime":U=(N.createTime||0)-(q.createTime||0);break;case"updateTime":U=(N.updateTime||0)-(q.updateTime||0);break}return ne?U:-U})}),I=j(()=>{const x=p.value.map(u=>({type:"song",data:u,key:u.id}));return a.loadMore!==void 0&&x.push({type:"footer",data:null,key:"footer"}),x}),O=j(()=>a.isDailyRecommend?`daily-${g.dailySongsData.timestamp||0}`:a.playListId?`playlist-${a.playListId}-${s.listSortField}-${s.listSortOrder}`:`list-${a.listVersion}-${a.type}-${s.listSortField}-${s.listSortOrder}`),_=j(()=>p.value.findIndex(x=>x.id===g.playSong.id)),{height:V,stop:P}=At(v),te=x=>{m("scroll",x);const u=x.target,T=u.scrollTop;w.value=T,$.value=Math.floor(T/90);const ne=u.scrollHeight,N=u.clientHeight;ne-T-N<100&&!a.loading&&a.loadMore&&m("reachBottom",x)},oe=()=>{e.value?.scrollToIndex(0)},X=()=>{_.value>=0&&e.value?.scrollToIndex(_.value)},ue=()=>{g.playPlaylistId===a.playListId&&b.updatePlayList(p.value,g.playSong,a.playListId,{showTip:!1,play:!1}),ve(()=>{_.value>=0?e.value?.scrollToIndex(_.value):e.value?.scrollToIndex(0)})},me=x=>{s.listSortField===x&&x!=="default"?s.listSortOrder=s.listSortOrder==="asc"?"desc":"asc":(s.listSortField=x,s.listSortOrder==="default"&&(x==="createTime"||x==="updateTime"||x==="duration"?s.listSortOrder="desc":s.listSortOrder="asc")),ue()},fe=x=>{s.listSortOrder=x,ue()},J=x=>m("removeSong",x);return Ft(()=>{S.value=!1}),Ht(()=>{S.value=!0,a.height==="auto"&&P(),$.value>0&&ve(()=>{e.value?.scrollToIndex($.value)})}),Be(()=>{P(),S.value=!1}),(x,u)=>{const T=ce,ne=Et,N=pe,q=Ut,U=Wt,ae=Vt,ie=So,je=po,ze=Ne,Me=ro,Ve=oo,Ue=Xt,Ee=Yt;return i(),c(le,{name:"fade",mode:"out-in"},{default:r(()=>[t(qt)(t(p))?o.loading?(i(),H("div",Io,[C(Ue,{repeat:10,text:""})])):(i(),c(Ee,{key:2,description:"列表光秃秃的，啥都没有哦",size:"large",class:"song-list empty"})):(i(),H("div",{key:0,ref_key:"songListRef",ref:v,class:"song-list"},[C(le,{name:"fade",mode:"out-in"},{default:r(()=>[(i(),H("div",{key:t(O),style:jt({height:o.height==="auto"?"auto":`${o.height||t(V)}px`,transition:o.disableHeightTransition?"transform 0.3s, opacity 0.3s":void 0}),class:"virtual-list-wrapper"},[F("div",Ro,[C(T,{class:"num"},{default:r(()=>[...u[4]||(u[4]=[h("#",-1)])]),_:1}),o.disabledSort?(i(),c(T,{key:1,class:"title"},{default:r(()=>[...u[8]||(u[8]=[h("标题",-1)])]),_:1})):(i(),c(ae,{key:0,trigger:"click",placement:"bottom-start","show-arrow":!1,style:{padding:"0"}},{trigger:r(()=>[F("div",Po,[C(T,null,{default:r(()=>[...u[5]||(u[5]=[h("标题",-1)])]),_:1}),t(s).listSortField!=="default"?(i(),c(T,{key:0,class:"sort",depth:"3"},{default:r(()=>[h(D(t(Te)[t(s).listSortField].name),1)]),_:1})):z("",!0)])]),default:r(()=>[F("div",To,[F("div",Lo,[u[6]||(u[6]=F("div",{class:"label"},"排序字段",-1)),C(q,{value:t(s).listSortField,"onUpdate:value":[u[0]||(u[0]=L=>t(s).listSortField=L),u[1]||(u[1]=L=>me(L))],name:"sortField"},{default:r(()=>[C(N,{vertical:!0,size:"small"},{default:r(()=>[(i(!0),H(de,null,be(t(Te),(L,Y)=>(i(),c(ne,{key:Y,value:Y},{default:r(()=>[h(D(L.name),1)]),_:2},1032,["value"]))),128))]),_:1})]),_:1},8,["value"])]),C(U,{vertical:"",style:{height:"auto",margin:"0 12px"}}),F("div",Bo,[u[7]||(u[7]=F("div",{class:"label"},"排序方式",-1)),C(q,{value:t(s).listSortOrder,"onUpdate:value":[u[2]||(u[2]=L=>t(s).listSortOrder=L),u[3]||(u[3]=L=>fe(L))],name:"sortOrder"},{default:r(()=>[C(N,{vertical:!0,size:"small"},{default:r(()=>[(i(!0),H(de,null,be(t(Gt),(L,Y)=>(i(),c(ne,{key:Y,value:Y},{default:r(()=>[h(D(L.name),1)]),_:2},1032,["value"]))),128))]),_:1})]),_:1},8,["value"])])])]),_:1})),o.type!=="radio"&&!o.hiddenAlbum&&!t(f)?(i(),c(T,{key:2,class:"album"},{default:r(()=>[...u[9]||(u[9]=[h(" 专辑 ",-1)])]),_:1})):z("",!0),o.type!=="radio"?(i(),c(T,{key:3,class:"actions"},{default:r(()=>[...u[10]||(u[10]=[h("操作",-1)])]),_:1})):z("",!0),o.type==="radio"&&!t(f)?(i(),c(T,{key:4,class:"meta date"},{default:r(()=>[...u[11]||(u[11]=[h("更新日期",-1)])]),_:1})):z("",!0),o.type==="radio"&&!t(f)?(i(),c(T,{key:5,class:"meta"},{default:r(()=>[...u[12]||(u[12]=[h("播放量",-1)])]),_:1})):z("",!0),t(f)?z("",!0):(i(),c(T,{key:6,class:"meta"},{default:r(()=>[...u[13]||(u[13]=[h("时长",-1)])]),_:1})),o.data?.[0].size&&!o.hiddenSize&&!t(f)?(i(),c(T,{key:7,class:"meta size"},{default:r(()=>[...u[14]||(u[14]=[h(" 大小 ",-1)])]),_:1})):z("",!0)]),C(Kt,{ref_key:"listRef",ref:e,"item-height":90,"item-fixed":!0,items:t(I),height:"calc(100% - 40px)","padding-bottom":80,onScroll:te},{default:r(({item:L,index:Y})=>[L.type==="song"?(i(),c(ie,{key:0,song:L.data,index:Y,hiddenCover:o.hiddenCover,hiddenAlbum:o.hiddenAlbum,hiddenSize:o.hiddenSize,onClick:K(re=>y(L.data),["stop"]),onDblclick:K(re=>k(L.data),["stop"]),onContextmenu:K(re=>d(re,L.data,Y),["stop"]),onShowMenu:re=>d(re,L.data,Y)},null,8,["song","index","hiddenCover","hiddenAlbum","hiddenSize","onClick","onDblclick","onContextmenu","onShowMenu"])):L.type==="footer"?(i(),H("div",Do,[o.loadMore&&o.loading?(i(),c(N,{key:0},{default:r(()=>[C(je,{size:"small"}),C(T,null,{default:r(()=>[h(D(o.loadingText||"努力加载中"),1)]),_:1})]),_:1})):(i(),c(U,{key:1,dashed:""},{default:r(()=>[...u[15]||(u[15]=[h(" 没有更多啦 ~ ",-1)])]),_:1}))])):z("",!0)]),_:1},8,["items"])],4))]),_:1}),C(_o,{ref_key:"songListMenuRef",ref:R,onRemoveSong:J},null,512),C(Mo,{ref_key:"mobileSongMenuRef",ref:n,onRemoveSong:J},null,512),(i(),c(Qt,{to:"body"},[C(le,{name:"fade",mode:"out-in"},{default:r(()=>[t(S)?(i(),c(Ve,{key:0,class:"list-menu"},{default:r(()=>[C(le,{name:"fade",mode:"out-in"},{default:r(()=>[t(w)>100?(i(),c(Me,{key:0,width:"42",onClick:oe},{default:r(()=>[C(ze,{size:22,name:"Up"})]),_:1})):z("",!0)]),_:1}),t(_)>=0?(i(),c(Me,{key:0,width:"42",onClick:X},{default:r(()=>[C(ze,{size:22,name:"Location"})]),_:1})):z("",!0)]),_:1})):z("",!0)]),_:1})]))],512))]),_:1})}}}),Ao=$e(Oo,[["__scopeId","data-v-04dffa82"]]);export{Ao as _};
