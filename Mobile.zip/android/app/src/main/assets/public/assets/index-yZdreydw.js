const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-B2Ocd7gO.js","./index-DVrhDZmS.js","./index-BH66geS8.css"])))=>i.map(i=>d[i]);
import{r,_ as p}from"./index-DVrhDZmS.js";const o=r("App",{web:()=>p(()=>import("./web-B2Ocd7gO.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.AppWeb)});export{o as App};
