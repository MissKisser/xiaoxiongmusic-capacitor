export { useShortcutStore } from "./shortcut";
export { useSettingStore } from "./setting";
export { useStatusStore } from "./status";
export { useMusicStore } from "./music";
export { useDataStore } from "./data";

// local-localforage
export { useLocalStore } from "./local";

// streaming-localforage
export { useStreamingStore } from "./streaming";

// auth & version
export { useAuthStore } from "./auth";
export { useVersionStore } from "./version";
